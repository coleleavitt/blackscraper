CREATE TABLE word (word TEXT, definition TEXT, wid INT PRIMARY KEY);
CREATE TABLE similar (wid INT, sid INT, FOREIGN KEY (wid) REFERENCES word(wid), FOREIGN KEY (sid) REFERENCES word(wid));

INSERT INTO word VALUES ('dark', 'having very little or no light', 1);
INSERT INTO word VALUES ('small', 'of limited size', 2);
INSERT INTO word VALUES ('happy', 'delighted, pleased, or glad, as over a particular thing', 3);
INSERT INTO word VALUES ('fast', 'moving or able to move, operate, function, or take effect quickly', 4);
INSERT INTO word VALUES ('cheap', 'costing very little', 5);

INSERT INTO word VALUES ('dim', '', 6);
INSERT INTO word VALUES ('dull', '', 7);
INSERT INTO word VALUES ('tiny', '', 8);
INSERT INTO word VALUES ('little', '', 9);
INSERT INTO word VALUES ('delighted', '', 10);
INSERT INTO word VALUES ('cheerful', '', 11);
INSERT INTO word VALUES ('speedy', '', 12);
INSERT INTO word VALUES ('rapid', '', 13);
INSERT INTO word VALUES ('brisk', '', 14);
INSERT INTO word VALUES ('bargain', '', 15);
INSERT INTO word VALUES ('economical', '', 16);

INSERT INTO similar VALUES (1, 6);
INSERT INTO similar VALUES (1, 7);
INSERT INTO similar VALUES (2, 8);
INSERT INTO similar VALUES (2, 9);
INSERT INTO similar VALUES (3, 10);
INSERT INTO similar VALUES (3, 11);
INSERT INTO similar VALUES (4, 12);
INSERT INTO similar VALUES (4, 13);
INSERT INTO similar VALUES (4, 14);
INSERT INTO similar VALUES (5, 15);
INSERT INTO similar VALUES (5, 16);
