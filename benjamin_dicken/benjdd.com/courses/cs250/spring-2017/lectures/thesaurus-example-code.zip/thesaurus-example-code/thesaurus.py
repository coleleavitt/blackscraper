###
### Author: Benjamin Dicken
### Description:
###   This program acts as a thesaurus.
###   Is uses a SQLite thesaurus database to get the similar words.
###

import sys
import sqlite3

print('Welcome to the thesaurus!')
print('What word would you like to know about?')

word = sys.stdin.readline().strip()

conn = sqlite3.connect('thesdb')
r1 = conn.execute("SELECT wid FROM word WHERE word == ?", (word,))
wid = r1.fetchone()

if wid is not None:
    print('Similar word(s) to "' + word + '": ')

    # First, query and print the word's definition

    # execute() returns a cursor object
    definition = conn.execute("SELECT definition FROM word WHERE word == ?", (word,))
    # fetchone() returns a tuple
    res1 = definition.fetchone()
    print(' The definition:' + res1[0])

    # Next, query and print the similar words

    sids = conn.execute("""SELECT similar.sid FROM word
                            JOIN similar on similar.wid == word.wid
                            WHERE similar.wid == ?""", (wid[0],))
    for sid in sids:
        r2 = conn.execute("SELECT word FROM word WHERE wid == ?", (sid[0],))
        word = r2.fetchone()
        print('  ' + str(word[0]))

else:
    print('Unable to find similar words to "' + word + '"')
