CREATE TABLE customer (
  first_name TEXT,
  last_name TEXT,
  uid INT PRIMARY KEY);
CREATE TABLE account (
  type TEXT,
  balance FLOAT,
  owner_uid INT,
  acct_id INT PRIMARY KEY,
  FOREIGN KEY (owner_uid) REFERENCES customer(uid));

INSERT INTO customer VALUES ('Ben', 'Dicken', 123);
INSERT INTO customer VALUES ('Joe', 'Smith', 345);
INSERT INTO customer VALUES ('James', 'Jones', 789);

INSERT INTO account VALUES ('CHECKING', 500.00, 123, 1);
INSERT INTO account VALUES ('SAVING', 7400.00, 123, 2);
INSERT INTO account VALUES ('CHECKING', 350.00, 345, 3);
INSERT INTO account VALUES ('SAVING', 5432.00, 345, 4);
INSERT INTO account VALUES ('SAVING', 3000.00, 789, 5);
