import sys
import sqlite3

print('Enter a account ID:')
acct_id = sys.stdin.readline().strip()
print('Enter money to deposit:')
dep = sys.stdin.readline().strip()

conn = sqlite3.connect('bankdb')
query = "UPDATE account SET balance = balance + " + dep + " WHERE acct_id == " + acct_id + ";"
res = conn.executescript(query)
conn.commit()
conn.close()
