import sys
import movieconn

while True:
    print('PYMDB: What would you like to know about movies?')
    cmd = sys.stdin.readline().strip()
    cmd_split = cmd.split()

    if cmd == 'exit':
        print('PYMDB: Bye!')
        conn.close()
        sys.exit()
    elif cmd_split[0] == 'DIRINFO':
        dir_first = cmd_split[1]
        dir_last  = cmd_split[2]
        results = movieconn.fetch_director_info(dir_first, dir_last)
        if len(results) > 0:
            print('  ' + str(results[0][0]) +
                  ' ' + str(results[0][1]) +
                  '(age ' + str(results[0][2]) +
                  ') has directed:')
            for row in results:
                print('    ' + str(row[3]) +
                      '(year=' + str(row[4]) +
                      ', rating=' + str(row[5]) + ')')
    elif cmd_split[0] == 'MOVINFO':
        mov_title = ' '.join(cmd_split[1:])
        results = movieconn.fetch_movie_info(mov_title)
        if results is not None:
            print('  ' + str(results[0]) +
                  '(year=' + str(results[1]) +
                  ', rating=' + str(results[2]) +
                  ') was directed by:')
            if results[3] is not None:
                print('    ' + str(results[3]) +
                      ' ' + str(results[4]) +
                      '(age ' + str(results[5]) +
                      ') has directed:')
    elif cmd_split[0] == 'ADDDIR':
        dir_first = cmd_split[1]
        dir_last  = cmd_split[2]
        dir_age   = cmd_split[3]
        dir_id    = cmd_split[4]
        movieconn.add_director(dir_first, dir_last, dir_age, dir_id)
        print('PYMDB: Director Added!')
    elif cmd_split[0] == 'ADDMOV':
        mov_title = cmd_split[1]
        mov_year  = cmd_split[2]
        mov_rat   = cmd_split[3]
        mov_mid   = cmd_split[4]
        mov_did   = cmd_split[5]
        movieconn.add_movie(mov_title, mov_year, mov_rat, mov_mid, mov_did)
        print('PYMDB: Movie Added!')
    else:
        print('PYMDB: Huh?')
