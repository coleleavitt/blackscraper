import sys

current_cmd = []
current_cmd_list = []

def fetch_user_command():
    global current_cmd
    global current_cmd_list
    print('PYMDB: What would you like to know amout movies?')
    current_cmd = sys.stdin.readline().strip()
    current_cmd_list = current_cmd.split()

def handle_exit():
    if current_cmd == 'exit':
        print('PYMDB: Bye!')
        sys.exit()

def get_command_list():
    return current_cmd_list

def is_dirinfo():
    return current_cmd_list[0] == 'DIRINFO'

def is_movinfo():
    return current_cmd_list[0] == 'MOVINFO'

def is_adddir():
    return current_cmd_list[0] == 'ADDDIR'

def is_addmov():
    return current_cmd_list[0] == 'ADDMOV'

def validate_command():
    if is_dirinfo() or is_movinfo() or is_adddir() or is_addmov():
        return True
    else:
        print('PYMDB: Huh?')
        return False

