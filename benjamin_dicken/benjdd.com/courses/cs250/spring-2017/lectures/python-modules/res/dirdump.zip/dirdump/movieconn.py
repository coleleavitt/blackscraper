import sys
import sqlite3
conn = sqlite3.connect('moviedb')

###
### Returns a list of tuples
### Each tuple has the first and last name of a director
###
def get_all_directors():
    results = []
    res = conn.execute('''SELECT * FROM director''')
    values = res.fetchall()
    for v in values:
        results.append( ( v[0], v[1]) )
    return results

###
### Returns a list of tuples with info about all movies for a specific director
### The director is specified by providing the function with the first and last name as arguments
###
def fetch_director_info(first_name, last_name):
    results = None
    params = (first_name, last_name)
    res1 = conn.execute('''SELECT * FROM director
                           WHERE first_name == ?
                           AND last_name == ?''', params)
    val = res1.fetchone()
    if val != None:
        params = (val[3],)
        res2 = conn.execute('''SELECT * FROM movie
                               WHERE movie.director_id == ?''', params)
        results = []
        for row in res2:
            res_row = (val[0], val[1], val[2], row[0], row[1], row[2])
            results.append(res_row)
    return results

###
### Returns a tuple with info about a particular movie
### To specify a movie, provide the title as an argument
###
def fetch_movie_info(title):
    results = None
    params = (title,)
    res1 = conn.execute('''SELECT * FROM movie
                           WHERE title == ?''', params)
    val = res1.fetchone()
    if val != None:
        params = (val[4],)
        res2 = conn.execute('''SELECT * FROM director
                               WHERE director_id == ?''', params)
        row = res2.fetchone()
        results = (val[0], val[1], val[2], None, None, None)
        if row != None:
            results = (val[0], val[1], val[2], row[0], row[1], row[2])
    return results

###
### Add a director with the specified parameters to the database
###
def add_director(first_name, last_name, age, did):
    params = (first_name, last_name, age, did)
    conn.execute('''INSERT INTO director VALUES (?,?,?,?)''', params)
    conn.commit()

###
### Add a movie with the specified parameters to the database
###
def add_movie(title, year, rat, mid, did):
    params = (title, year, rat, mid, did)
    conn.execute('''INSERT INTO movie VALUES (?,?,?,?,?)''', params)
    conn.commit()

###
### Commit and close the database connection
###
def finished():
   conn.commit()
   conn.close()

