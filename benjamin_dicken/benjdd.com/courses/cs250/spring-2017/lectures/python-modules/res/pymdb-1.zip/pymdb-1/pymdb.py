import sys
import sqlite3
conn = sqlite3.connect('moviedb')

while True:
    print('PYMDB: What would you like to know about movies?')
    cmd = sys.stdin.readline().strip()
    cmd_split = cmd.split()

    if cmd == 'exit':
        print('PYMDB: Bye!')
        conn.close()
        sys.exit()
    elif cmd_split[0] == 'DIRINFO':
        dir_first = cmd_split[1]
        dir_last  = cmd_split[2]
        params = (dir_first, dir_last)
        res1 = conn.execute('''SELECT * FROM director
                               WHERE first_name == ?
                               AND last_name == ?''', params)
        val = res1.fetchone()
        if val != None:
            print('  ' + str(val[0]) +
                  ' ' + str(val[1]) +
                  '(age ' + str(val[2]) +
                  ') has directed:')
            params = (val[3],)
            res2 = conn.execute('''SELECT * FROM movie
                                   WHERE movie.director_id == ?''', params)
            for row in res2:
                print('    ' + str(row[0]) +
                      '(year=' + str(row[1]) +
                      ', rating=' + str(row[2]) + ')')
    elif cmd_split[0] == 'MOVINFO':
        mov_title = ' '.join(cmd_split[1:])
        params = (mov_title,)
        res1 = conn.execute('''SELECT * FROM movie
                               WHERE title == ?''', params)
        val = res1.fetchone()
        if val != None:
            print('  ' + str(val[0]) +
                  '(year=' + str(val[1]) +
                  ', rating=' + str(val[2]) +
                  ') was directed by:')
            params = (val[4],)
            res2 = conn.execute('''SELECT * FROM director
                                   WHERE director_id == ?''', params)
            val = res2.fetchone()
            if val != None:
                print('    ' + str(val[0]) +
                      ' ' + str(val[1]) +
                      '(age ' + str(val[2]) +
                      ') has directed:')
    elif cmd_split[0] == 'ADDDIR':
        dir_first = cmd_split[1]
        dir_last  = cmd_split[2]
        dir_age   = cmd_split[3]
        dir_id    = cmd_split[4]
        params = (dir_first, dir_last, dir_age, dir_id)
        conn.execute('''INSERT INTO director VALUES (?,?,?,?)''', params)
        conn.commit()
        print('PYMDB: Director Added!')
    elif cmd_split[0] == 'ADDMOV':
        mov_title = cmd_split[1]
        mov_year  = cmd_split[2]
        mov_rat   = cmd_split[3]
        mov_mid   = cmd_split[4]
        mov_did   = cmd_split[5]
        params = (mov_title, mov_year, mov_rat, mov_mid, mov_did)
        conn.execute('''INSERT INTO movie VALUES (?,?,?,?,?)''', params)
        conn.commit()
        print('PYMDB: Movie Added!')
    else:
        print('PYMDB: Huh?')
