import movieconn

results = movieconn.get_all_directors()
for director in results:
    results = movieconn.fetch_director_info(director[0], director[1])
    print( director[0] + ' ' + director[1] + ' has directed: ')
    for row in results:
        print('  ' + row[3])
