import command
import movieconn

while True:
    command.fetch_user_command()
    command.handle_exit()
    command.validate_command()

    command_list = command.get_command_list()

    if command.is_dirinfo():
        dir_first = command_list[1]
        dir_last  = command_list[2]
        results = movieconn.fetch_director_info(dir_first, dir_last)
        if len(results) > 0:
            print('  ' + str(results[0][0]) +
                  ' ' + str(results[0][1]) +
                  '(age ' + str(results[0][2]) +
                  ') has directed:')
            for row in results:
                print('    ' + str(row[3]) +
                      '(year=' + str(row[4]) +
                      ', rating=' + str(row[5]) + ')')

    elif command.is_movinfo():
        mov_title = ' '.join(command_list[1:])
        results = movieconn.fetch_movie_info(mov_title)
        if results is not None:
            print('  ' + str(results[0]) +
                  '(year=' + str(results[1]) +
                  ', rating=' + str(results[2]) +
                  ') was directed by:')
            if results[3] is not None:
                print('    ' + str(results[3]) +
                      ' ' + str(results[4]) +
                      '(age ' + str(results[5]) +
                      ') has directed:')
    elif command.is_adddir():
        dir_first = command_list[1]
        dir_last  = command_list[2]
        dir_age   = command_list[3]
        dir_id    = command_list[4]
        movieconn.add_director(dir_first, dir_last, dir_age, dir_id)
        print('PYMDB: Director Added!')
    elif command.is_addmov():
        mov_title = command_list[1]
        mov_year  = command_list[2]
        mov_rat   = command_list[3]
        mov_mid   = command_list[4]
        mov_did   = command_list[5]
        movieconn.add_movie(mov_title, mov_year, mov_rat, mov_mid, mov_did)
        print('PYMDB: Movie Added!')

