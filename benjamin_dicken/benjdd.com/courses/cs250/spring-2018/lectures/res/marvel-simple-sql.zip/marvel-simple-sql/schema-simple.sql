CREATE TABLE person(
  name TEXT,
  pid INT);

CREATE TABLE movie(
  title TEXT,
  mid INT);

CREATE TABLE character(
  name TEXT,
  description TEXT,
  age INT,
  is_good BOOLEAN,
  appearances INT,
  cid INT,
  pid INT,
  FOREIGN KEY(pid) REFERENCES person(pid));
