CREATE TABLE person(
  name TEXT,
  pid INT PRIMARY KEY);

CREATE TABLE movie(
  title TEXT,
  mid INT PRIMARY KEY);

CREATE TABLE character(
  name TEXT,
  description TEXT,
  age INT,
  is_good BOOLEAN,
  appearances INT,
  cid INT PRIMARY KEY,
  pid INT,
  FOREIGN KEY (pid) REFERENCES person(pid) );

CREATE TABLE characterIn (
  cid INT,
  mid INT,
  FOREIGN KEY (cid) REFERENCES character(cid),
  FOREIGN KEY (mid) REFERENCES movie(mid) );

CREATE TABLE directs (
  pid INT,
  mid INT,
  FOREIGN KEY (pid) REFERENCES person(pid),
  FOREIGN KEY (mid) REFERENCES movie(mid) );

CREATE TABLE actsIn (
  pid INT,
  mid INT,
  FOREIGN KEY (pid) REFERENCES person(pid),
  FOREIGN KEY (mid) REFERENCES movie(mid) );

