import sys
import sqlite3
import matplotlib.pyplot as plt
import csv

data = list(csv.reader(open('earthquakes.csv')))

lat = []
long = []
sig = []
for i in data:
    lat.append(float(i[6]))
    long.append(float(i[8]))
    sig.append(float(i[14]))

num_bins = 50

fig = plt.figure()
ax = fig.add_subplot(1, 1, 1)

ax.hist2d(lat, long, bins=num_bins, weights=sig, cmap=plt.cm.inferno)
ax.set_xlabel('lat')
ax.set_ylabel('long')
ax.set_title('Earthquake data')
plt.show()