import sys
import matplotlib.pyplot as plt
import csv

data = list(csv.reader(open('earthquakes.csv')))

lat = []
long = []
sig = []
for i in data:
    lat.append(float(i[6]))
    long.append(float(i[8]))
    sig.append(float(i[14]))

num_bins = 50

fig = plt.figure()
ax = fig.add_subplot(1, 1, 1)
ax.scatter(lat, long, cmap=plt.cm.inferno, alpha=0.01)
ax.set_xlabel('lat')
ax.set_ylabel('long')
ax.set_title('Earthquake data')
plt.show()