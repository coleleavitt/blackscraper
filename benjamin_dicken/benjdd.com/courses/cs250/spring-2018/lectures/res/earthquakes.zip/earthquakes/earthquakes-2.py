import sys
import sqlite3
import matplotlib.pyplot as plt
import csv

data = list(csv.reader(open('earthquakes.csv')))

mag = []
depth = []
for i in data:
    mag.append(float(i[9]))
    depth.append(float(i[1]))

num_bins = 20

fig = plt.figure()
ax = fig.add_subplot(1, 1, 1)

ax.scatter(mag, depth, alpha=0.2, cmap=plt.cm.inferno)
ax.set_xlabel('magnitude')
ax.set_ylabel('depth')
ax.set_title('Earthquake data')
plt.show()