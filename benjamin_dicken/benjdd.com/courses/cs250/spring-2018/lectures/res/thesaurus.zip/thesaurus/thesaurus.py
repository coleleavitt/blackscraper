thes = {}

def add_word(add_str):
    split1 = add_str.split(' : ')
    key = split1[0]
    value = split1[1].split(' ')
    thes[key] = set(value)
    
def save_thes():
    f = open('thesaurus.txt', 'w')
    for k, v in thes.items():
        l = list(v)
        f.write(k + ' : ' + ' '.join(l) + '\n')
    f.close()
    
def main():
    f = open('thesaurus.txt', 'r')
    lines = f.readlines()
    for line in lines:
        add_word(line.strip('\n'))
    
    print(thes)
    
    while True:
        text = input('> ')
        if text == 'exit':
            print('Bye!')
            break
        elif text.startswith('ADD'):
            new_word = input('What word to add? ')
            sim_words = input('What are the similar words? ')
            sp = sim_words.split(' ')
            if new_word not in thes:
                thes[new_word] = set()
            for i in sp:
                thes[new_word].add(i)
            save_thes()
        else:
            if text in thes:
                similar = thes[text]
                print('words similar to ' + text + ' are:')
                print('  ' + ' '.join(similar))
            else:
                print('Sorry, I do not know that word')

            pass

main()