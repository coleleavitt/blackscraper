###
### Author: Benjamin Dicken
### Description:
###   This program acts as a thesaurus.
###   Is uses a SQLite thesaurus database to get the similar words.
###

import sys
import sqlite3
 
conn = sqlite3.connect('thes.db')

def get_ids_forward(wid):
    res = conn.execute("SELECT sid FROM similar WHERE wid == " + str(wid))
    ids = []
    for i in res:
       ids.append(i[0])
    return ids

def get_ids_backward(wid):
    r = conn.execute("SELECT wid FROM similar WHERE sid == " + str(wid))
    ids = []
    sim_wid = r.fetchone()
    if sim_wid != None:
        print(sim_wid)
        ids.extend(get_ids_forward(sim_wid[0]))
    return ids

def print_words_with_ids(ids):
    for i in ids:
        r2 = conn.execute("SELECT word FROM word WHERE wid == " + str(i))
        word = r2.fetchone()
        print('  ' + str(word[0]))

def main():
    print('Welcome to the thesaurus!')
    print('What word would you like to know about?')

    word = input().strip()

    r1 = conn.execute("SELECT wid FROM word WHERE word == '" + str(word) + "'")
    wid = r1.fetchone()
    if wid is not None:
        print('Similar word(s) to "' + word + '": ')
        ids = get_ids_forward(wid[0])
        print_words_with_ids(ids)
        ids = get_ids_backward(wid[0])
        print_words_with_ids(ids)
    else:
        print('Unable to find similar words to "' + word + '"')

main()
