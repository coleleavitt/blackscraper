###
### Author: Benjamin Dicken
### Description:
###   This program acts as a thesaurus.
###   Is uses a SQLite thesaurus database to get the similar words.
###

import sys
import sqlite3
 
conn = sqlite3.connect('thes.db')

def get_ids_forward(wid):
    res = conn.execute("SELECT sid FROM similar WHERE wid == " + str(wid))
    ids = []
    for i in res:
       ids.append(i[0])
    return ids

def print_words_with_ids(ids):
    for i in ids:
        r2 = conn.execute("SELECT word FROM word WHERE wid == " + str(i))
        word = r2.fetchone()
        print('  ' + str(word[0]))

def get_word_id(w):
    result = conn.execute('SELECT wid FROM word WHERE word == \'' + w + '\';')
    e = result.fetchone()
    return e[0]

def add_similarity(word_a, word_b):
    id_a = get_word_id(word_a)
    id_b = get_word_id(word_b)
    conn.execute('INSERT INTO similar (wid, sid) VALUES (' + str(id_a) + ', ' + str(id_b) + ');')
    conn.execute('INSERT INTO similar (wid, sid) VALUES (' + str(id_b) + ', ' + str(id_a) + ');')

def add_word(w):
    result = conn.execute('SELECT * FROM word WHERE word == \'' + w + '\';')
    r = result.fetchone()
    if r == None:
        conn.execute('INSERT INTO word (word) VALUES (\'' + w + '\');')

def process_add_command(w, sim):
    add_word(w)
    add_word(sim)
    add_similarity(w, sim)

def main():
    print('Welcome to the thesaurus!')
    print('What would you like to do?')
    command = input().strip()
    sp = command.split(' ')
 
    if sp[0] == 'add':
       word_to_add = sp[1]
       sim = input('similar word: ')
       process_add_command(word_to_add, sim)

    elif sp[0] == 'get':
        r1 = conn.execute("SELECT wid FROM word WHERE word == '" + str(sp[1]) + "'")
        wid = r1.fetchone()
        if wid is not None:
            print('Similar word(s) to "' + sp[1] + '": ')
            ids = get_ids_forward(wid[0])
            print_words_with_ids(ids)

    else:
        print('Unable to find similar words to "' + sp[1] + '"')

    conn.commit()
    conn.close()

main()
