###
### Author: Benjamin Dicken
### Description:
###   This program acts as a thesaurus.
###   Is uses a SQLite thesaurus database to get the similar words.
###

import sys
import sqlite3

def main():
    print('Welcome to the thesaurus!')
    print('What word would you like to know about?')

    word = input().strip()

    conn = sqlite3.connect('thes.db')
    r1 = conn.execute("SELECT wid FROM word WHERE word == '" + str(word) + "'")
    wid = r1.fetchone()
    if wid is not None:
        print('Similar word(s) to "' + word + '": ')
        sids = conn.execute("SELECT sid FROM similar WHERE wid == " + str(wid[0]))
        for sid in sids:
            r2 = conn.execute("SELECT word FROM word WHERE wid == " + str(sid[0]))
            word = r2.fetchone()
            print('  ' + str(word[0]))
    else:
        print('Unable to find similar words to "' + word + '"')

main()
