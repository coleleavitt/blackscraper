#!/bin/bash

echo "----------------------------------------------"
echo "This is an MadLib script that takes five words: name1, name2, adjective, adverb, place."
echo ""

echo "----------------------------------------------"
echo "*PERSON1*: Hey *PERSON2* ! How goes it?"
echo "*PERSON2*: Good. You wanna go to *PLACE* and play some *ADJECTIVE* video games?"
echo "*PERSON1*: Sure. But first I need to *ADVERB* run some errands."
echo "*PERSON2*: OK, see you at *PLACE* in a bit!"
