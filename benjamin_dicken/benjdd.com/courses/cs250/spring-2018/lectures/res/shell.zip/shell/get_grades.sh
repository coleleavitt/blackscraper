#!/bin/bash -x

GRADES_105=${1}
GRADES_205=${2}

TOP=$( cat ${GRADES_105} | cut -d ',' -f 3 | sort -n | tail -n 1)
cat ${GRADES_205} | grep ${TOP} | cut -d ',' -f 1,2

