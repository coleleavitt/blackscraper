import sys
import sqlite3

### Take the command
print('MARVEL: Welcome to the DBMS.')
print('MARVEL: Enter a command:')
cmd_str = sys.stdin.readline().rstrip()
cmd     = cmd_str.split()

### Parse the important parts of the script
cmd_col    = cmd[1]
cmd_if_col = cmd[3]
cmd_if_op  = cmd[4]
cmd_if_val = cmd_str[ cmd_str.index('= ') + 2 : ]

condition = cmd_if_col + ' ' + cmd_if_op + '\'' + cmd_if_val + '\''
if cmd_col == 'all':
    cmd_col = '*'

conn = sqlite3.connect('marvel.db')
query = 'SELECT ' + cmd_col + ' FROM marvel WHERE ' + condition + ';'
query_res = conn.execute(query)
for row in query_res:
    for col in row:
        print(str(col), end='  ')
    print()
