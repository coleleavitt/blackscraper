import sqlite3
conn = sqlite3.connect('marvel.db')

conn.execute('''CREATE TABLE marvel(
             name STRING,
             id STRING,
             align STRING,
             EYE STRING,
             hair STRING,
             sex STRING,
             appearances STRING,
             year STRING);''')

# Load in all of the data
f = open('marvel-data.csv', 'r')
for line in f:
    line = line.strip('\n').split(',')
    # Ignore rows with more than 7 commas
    if len(line) == 8:
        values = '\'' + '\', \''.join(line) + '\''
        query = 'INSERT INTO marvel VALUES (' + values + ');'
        print(query)
        conn.execute(query) 

conn.commit()
conn.close()

