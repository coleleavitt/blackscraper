import sys

def get_index_from_name(name):
    indexes = {'name':0, 'identity':1, 'orientation':2, 'eyes':3,
               'hair':4,      'sex':5, 'appearances':6, 'year':7}
    if name in indexes:
        return indexes[name]
    return -1

### Populate the data list with the csv contents
data = []
for line in open('marvel-data.csv', 'r'):
    sp = line.strip().split(',')
    data.append(sp)

### Take the command
print('MARVEL: Welcome to the DBMS.')
print('MARVEL: Enter a command:')
cmd_str = sys.stdin.readline().rstrip()
cmd     = cmd_str.split()

### Parse the important parts of the script
cmd_col    = cmd[1]
cmd_if_col = cmd[3]
cmd_if_op  = cmd[4]
cmd_if_val = cmd_str[ cmd_str.index('= ') + 2 : ]

### get the index of the things to print and the condition check
pi    = get_index_from_name(cmd_col)
index = get_index_from_name(cmd_if_col)

print('MARVEL: Command results:')
for row in data:
    include = False
    if cmd_if_op == '==':
        if str(row[index]) == str(cmd_if_val):
            include = True
    elif cmd_if_op == '!=':
        if str(row[index]) != str(cmd_if_val):
            include = True
    
    if include:
        if cmd_col == 'all':
            print(', '.join(row).strip())
        else:
            print(row[pi].strip())
