import matplotlib.pyplot as plt
import csv

data = list(csv.reader(open('medical.csv')))

def get_data_to_visualize(states, problem):
    adrs = {}
    labels = []
    years = []
    for i in data:
        state = i[3]
        if state in states and i[2] == problem:
            if state not in adrs:
                adrs[state] = []
                labels.append(state)
            adrs[state].append(float(i[5]))
            if int(i[0]) not in years:
                years.append(int(i[0]))
    return (list(adrs.values()), years, labels) 

state_groups = { 'east': ['New York', 'Maine', 'Virginia', 'Massachusets', 'North Carolina', 'South Carolina', 'New Jersey'],
                 'west': ['California', 'Oregon', 'Washington']}
problems = ['Diseases of Heart', 'Diabetes']

fig = plt.figure()
i = 0
for p in problems:
    j = 0
    for k,v in state_groups.items():
        a, y, l = get_data_to_visualize(v, p)
        sp = fig.add_subplot(2, 2, i * len(state_groups) + j + 1)
        sp.stackplot(y, a, labels=l)
        sp.set_xlabel('Year')
        sp.set_ylabel(k + ' / ' + p)
        sp.legend(loc=2)
        j += 1
    i += 1

plt.show()

