import matplotlib.pyplot as plt
import csv

data = list(csv.reader(open('medical.csv')))

def get_adrs_years_for_states(states, problem):
    adrs = []
    years = []
    for i in data:
        if i[3] in states and i[2] == problem:
            adrs.append(float(i[5]))
            years.append(int(i[0]))
    return (adrs, years) 

state_groups = { 'east': ['New York', 'Maine', 'Virginia', 
                          'Massachusets', 'North Carolina', 
                          'South Carolina', 'New Jersey'],
                 'west': ['California', 'Oregon', 'Washington']}

problems = ['Diseases of Heart', 'Diabetes']

fig = plt.figure()
i = 0
for p in problems:
    j = 0
    for k, v in state_groups.items():
        a, y = get_adrs_years_for_states(v, p)
        sp = fig.add_subplot(2, 2, i * len(state_groups) + j + 1)
        sp.scatter(y, a, alpha=0.5)
        sp.set_xlabel('Year')
        sp.set_ylabel(k + ' / ' + p)
        j += 1
    i += 1

plt.show()
