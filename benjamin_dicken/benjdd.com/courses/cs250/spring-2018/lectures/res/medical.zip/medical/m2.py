import matplotlib.pyplot as plt
import csv

data = list(csv.reader(open('medical.csv')))

def get_adrs_years(reason, state):
    adrs = []
    years = []
    for i in data:
        if i[2] == reason and i[3] == state:
            adrs.append(float(i[5]))
            years.append(int(i[0]))
    return (adrs, years) 

fig = plt.figure()

problems = ['Cancer', 'Kidney Disease', 'Unintentional Injuries']
state = 'Arizona'

for i in range(len(problems)):
    a, y = get_adrs_years(problems[i], state)
    sp = fig.add_subplot(1, 3, i+1)
    sp.plot(y, a)
    sp.set_xlabel('Year')
    sp.set_ylabel(problems[i] + ' / ' + state)

plt.show()
