import matplotlib.pyplot as plt
import csv

data = list(csv.reader(open('medical.csv')))

def get_adrs_years():
    adrs = []
    years = []
    for i in data:
        if i[3] == 'United States' and i[5] != '':
            adrs.append(float(i[5]))
            years.append(int(i[0]))
    return (adrs, years) 

fig = plt.figure()

a, y = get_adrs_years()
sp = fig.add_subplot(1, 1, 1)
sp.scatter(y, a, alpha=0.3)
sp.set_xlabel('Year')
sp.set_ylabel('')

plt.show()
