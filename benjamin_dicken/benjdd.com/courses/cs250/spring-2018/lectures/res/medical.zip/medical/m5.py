import matplotlib.pyplot as plt
import csv

data = list(csv.reader(open('medical.csv')))

def get_bins_and_labels(reason, year):
    adrs = []
    labels = []
    for i in data:
        if i[2] == reason and int(i[0]) == year:
            adrs.append(float(i[5]))
            labels.append(i[3])
    return (adrs, labels) 

fig = plt.figure()

a, l = get_bins_and_labels('All Causes', 2000)
plt.xticks(fontsize=10, rotation=45)
plt.xticks(range(len(l)), l)
sp = fig.add_subplot(1, 1, 1)
sp.set_xticklabels(l)
sp.bar(range(len(a)), a)

plt.show()

