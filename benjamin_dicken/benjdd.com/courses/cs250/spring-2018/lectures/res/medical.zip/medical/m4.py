import matplotlib.pyplot as plt
import csv

data = list(csv.reader(open('medical.csv')))

def get_adrs_years(reason, state):
    adrs = []
    years = []
    for i in data:
        if i[2] == reason and i[3] == state:
            adrs.append(float(i[5]))
            years.append(int(i[0]))
    return (adrs, years) 

fig = plt.figure()

problems = ['Cancer', 'Kidney Disease', 'Unintentional Injuries']
states = ['United States', 'Arizona']

for i in range(len(problems)):
    for j in range(len(states)):
        a, y = get_adrs_years(problems[i], states[j])
        sp = fig.add_subplot(len(states), len(problems), (i * len(states)) + j+1 )
        sp.plot(y, a)
        sp.set_xlabel('Year')
        sp.set_ylabel(problems[i] + ' / ' + states[j])

plt.show()
