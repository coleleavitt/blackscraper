thes = {}

def add_word(add_str):
    split1 = add_str.split(' : ')
    key = split1[0]
    value = split1[1].split(' ')
    thes[key] = value
    
def main():
    f = open('thesaurus.txt', 'r')
    lines = f.readlines()
    for line in lines:
        add_word(line)
    
    print(thes)
    
    while True:
        text = input('> ')
        if text == 'exit':
            print('Bye!')
            break
        elif text.startswith('ADD'):
            new_word = input('What word to add? ')
            sim_words = input('What are the similar words? ')
            sp = sim_words.split(' ')
            if new_word not in thes:
                thes[new_word] = []
            for i in sp:
                thes[new_word].append(i)
            pass
        else:
            if text in thes:
                similar = thes[text]
                print('words similar to ' + text + ' are:')
                print('  ' + ' '.join(similar))
            else:
                print('Sorry, I do not know that word')

            pass

main()