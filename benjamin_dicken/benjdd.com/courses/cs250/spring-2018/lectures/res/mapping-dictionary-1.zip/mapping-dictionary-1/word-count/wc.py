fn = input('file name: ')
f = open(fn, 'r')

all_words = []

for line in f:
    sp = line.strip('\n ' ).split(' ')
    all_words.extend(sp)
    
#print(all_words)

counts = {}

for word in all_words:
    if word in counts:
        counts[word] += 1
    else:
        counts[word] = 1
        
#counts.sort()

count_to_words = {}
    
for key, value in counts.items():
    if value not in count_to_words:
        count_to_words[value] = []
    count_to_words[value].append(key)
    
sorted_counts = list(count_to_words.keys())
sorted_counts.sort()
sorted_counts.reverse()

for count in sorted_counts:
    for k, v in counts.items():
        if (v == count):
            print('count : ' + str(count) + ' --> ' + k)

