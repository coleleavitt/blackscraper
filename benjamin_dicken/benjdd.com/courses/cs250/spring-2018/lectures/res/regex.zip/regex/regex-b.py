import re
f = open('data.txt', 'r')
odd_a = 0
even_a = 0
even = r'(\b[A-Z]\w(\w\w)*\b)'
odd = r'(\b[A-Z](\w\w)*\b)'
pattern_odd = re.compile(odd)
pattern_even = re.compile(even)
for line in f:
    results = pattern_odd.findall(line)
    odd_a += len(results)
    results = pattern_even.findall(line)
    even_a += len(results)


print('Even-length: ' + str(even_a))
print('Odd-length: ' + str(odd_a))
