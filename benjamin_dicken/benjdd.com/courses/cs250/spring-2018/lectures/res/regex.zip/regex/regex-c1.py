import re
f = open('data.txt', 'r')
appearances = 0
regex_str = r'\b\w*[aeiou]\w*[aeiou]\w*[aeiou]\w*[aeiou]\w*[aeiou]\w*[aeiou]\w*[aeiou]\w*\b'
pattern = re.compile(regex_str)
counts = {}
for line in f:
    results = pattern.findall(line)
    appearances += len(results)
    for w in results:
        if w not in counts:
            counts[w] = 0
        counts[w] += 1     

keys = list(counts.keys())
keys.sort()
for k in keys:
    print(k + ' -> ' + str(counts[k]))
#print('Words with two or more double-letters appear ' + str(appearances) + ' times.')
