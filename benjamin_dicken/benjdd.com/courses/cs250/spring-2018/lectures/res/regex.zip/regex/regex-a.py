import re
f = open('data.txt', 'r')
appearances = 0
regex_str = r'(\w*(\w)\2\w*(\w)\3\w*)'
pattern = re.compile(regex_str)
counts = {}
for line in f:
    results = pattern.findall(line)
    appearances += len(results)
    for groups in results:
        w = groups[1]
        x = groups[2]
        if w not in counts:
            counts[w] = 0
        counts[w] += 1
        if x not in counts:
            counts[x] = 0
        counts[x] += 1        

keys = list(counts.keys())
keys.sort()
for k in keys:
    print(k + ' -> ' + str(counts[k]))
#print('Words with two or more double-letters appear ' + str(appearances) + ' times.')
