import re
f = open('data.txt', 'r')
appearances = 0
regex_str = r'\b\w*[aeiou]\w*[aeiou]\w*[aeiou]\w*\b'
pattern = re.compile(regex_str)
for line in f:
    results = pattern.findall(line)
    appearances += len(results)
    #for word in results:
    #    print(word)


print('Words containing 3+ vowels appear ' + str(appearances) + ' times.')
