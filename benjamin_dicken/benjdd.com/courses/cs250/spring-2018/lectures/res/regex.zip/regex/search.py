f = open('data.txt', 'r')
appearances = 0
for line in f:
    line = line.split(' ')
    for word in line:
        vowel_count = word.count('a') + word.count('e') + word.count('i') + word.count('o') + word.count('u')
        if vowel_count >= 3:
            appearances += 1
            print(word)

print('Words containing 3+ vowels appear ' + str(appearances) + ' times.')

