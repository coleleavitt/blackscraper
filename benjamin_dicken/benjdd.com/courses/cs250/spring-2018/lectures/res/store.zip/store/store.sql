
DROP TABLE IF EXISTS user;
DROP TABLE IF EXISTS product;
DROP TABLE IF EXISTS purchase;

CREATE TABLE user (
  username TEXT,
  password TEXT,
  address TEXT,
  cc_num TEXT,
  user_id INT PRIMARY KEY);

CREATE TABLE product (
  name TEXT,
  price FLOAT,
  description TEXT,
  product_id INT PRIMARY KEY);

CREATE TABLE purchase (
  user_id INT,
  product_id INT,
  FOREIGN KEY (user_id) REFERENCES user(user_id),
  FOREIGN KEY (product_id) REFERENCES product(product_id));

INSERT INTO user VALUES('john', 'pass', 'Address 1', '1234-5667-92929', 0);
INSERT INTO user VALUES('caryn', 'onetwothree', 'Address 2', '1212-3434-55755', 1);
INSERT INTO user VALUES('conley', 'abc123', 'Address 3', '9873-1275-75177', 2);
-- Plus many more ...

INSERT INTO product VALUES ('nest thermostat', 249.99, 'A learning thermostat', 100);
INSERT INTO product VALUES ('Whiteboard Marker', 1.99, 'A Dry-erase marker for whiteboards', 200);
INSERT INTO product VALUES ('Macbook Pro', 1599.99, 'A Laptop for hipsters', 300);
INSERT INTO product VALUES ('John Wick BluRay', 19.99, 'Awesome action movie', 400);
-- Plus many more ...

INSERT INTO purchase VALUES(2, 400);
INSERT INTO purchase VALUES(0, 100);
INSERT INTO purchase VALUES(1, 300);
INSERT INTO purchase VALUES(0, 300);
INSERT INTO purchase VALUES(1, 400);
INSERT INTO purchase VALUES(2, 200);
INSERT INTO purchase VALUES(2, 300);
-- Plus many more ...
