import sys
import sqlite3
conn = sqlite3.connect('store.db')

username = input('What is your username? ')
password = input('What is your password? ')

query = """SELECT product.name FROM purchase
  JOIN user ON user.user_id == purchase.user_id
  JOIN product ON product.product_id == purchase.product_id
  WHERE user.username == '""" + username + """'
    AND user.password == '""" + password + """';"""

print('Your purchases:')
results = conn.execute(query)
for row in results:
    print('  ' + row[0])

conn.commit()
conn.close()

