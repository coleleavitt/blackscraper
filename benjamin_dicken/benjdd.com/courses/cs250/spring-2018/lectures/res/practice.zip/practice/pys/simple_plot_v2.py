# Import the matplotlib pyplot submodule
# If you get a python error on this line, you might need to install matplotlib
import matplotlib.pyplot as plt

# Made-up data for plotting
x = [1, 2, 3, 4, 5, 6, 7, 8, 9]
y = [7, 3, 0, 3, 7, 3, 0, 7, 3]

# Create a figure object
# This is used to put your plots in
fig = plt.figure()

# Add a subplot to your figure
ax = fig.add_subplot(1, 1, 1)

# Tell the subplot what data you want to . . . plot!
ax.plot(x, y)

# Give the plot labels for x avix, y axis, and title
ax.set_xlabel('X')
ax.set_ylabel('Y')
ax.set_title('Plot of made-up data')

# Put the gridlines on the screen
ax.grid()

# Show it on in the window!
plt.show()
