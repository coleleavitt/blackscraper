def print_custom_rectangle(char, width, height):
    print(char * width)
    while (height-2) > 0:
        print(char + ' ' * (width-2) + char)
        height -= 1
    print(char * width)

