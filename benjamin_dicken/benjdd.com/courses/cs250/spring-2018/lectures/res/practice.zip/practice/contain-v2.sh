#!/bin/bash

TERM=${1}
SEARCH_DIR=${2}

# TODO

