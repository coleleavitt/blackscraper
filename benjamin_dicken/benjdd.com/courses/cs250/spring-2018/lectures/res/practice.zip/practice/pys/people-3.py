def head():
    print(" /-----\ ")
    print("| o   o |")
    print("\  ___  /")
    print(" \-----/ ")
    
def legs():
    print("   / \   ")
    print("  /   \  ")
    print(" /     \ ")

def person_one():
    head()
    print("<__|||__>")
    print("   |||   ")
    legs()
    print()
    
def person_two():
    head()
    print("    X    ")
    print(" __/ \__ ")
    print("   [+]   ")
    print("   |_|   ")
    legs()
    print()
    
def person_three():
    head()
    print(" <<XXX>> ")
    print("   XXX   ")
    legs()
    print()


person_one()
person_two()
person_three()
