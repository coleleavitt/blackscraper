###
### Author: Benjamin Dicken
### Description: This is a program used to track sports game logs
###

actions = []
players = []
teams   = []
times   = []

def show_log():
    print('GAME LOG:')
    for i in range(len(actions)):
        print('  At ' + times[i] + ': ' + players[i] + ' on team ' + teams[i] + ' ' + actions[i])

def add_event(action, player, team, time):
    actions.append(action)
    players.append(player)
    teams.append(team)
    times.append(time)

def main():
    command = ''
    while command != 'GAME OVER':
        command = input('Enter command: ')
        if (command.startswith('EVENT')):
            event_info = input('Specify ACTION PLAYER TEAM TIME: ')
            sc = event_info.split(' ')
            if len(sc) == 4:
                add_event(sc[0], sc[1], sc[2], sc[3])
            else:
                print('invalid format')
        elif (command == 'LOG'):
            show_log()
        else:
            print('Command not recognized')

main()
