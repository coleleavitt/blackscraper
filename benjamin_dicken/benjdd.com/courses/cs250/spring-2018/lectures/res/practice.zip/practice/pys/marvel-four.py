import sys
import sqlite3
import matplotlib.pyplot as plt

conn = sqlite3.connect('marvel.db')

query = "SELECT year, appearances FROM marvel ORDER BY year;"
res = conn.execute(query)

y = []
a = []
for row in res:
    if (row[0] != ''):
        y.append(int(row[0]))
        a.append(int(row[1]))

fig, axs = plt.subplots(2, 2, figsize=(5, 5))
axs[0, 0].hist(y, weights=a)
axs[1, 0].scatter(y, a)
axs[0, 1].plot(y, a)
axs[1, 1].hist2d(y, y)

plt.show()