import sys
import sqlite3
import matplotlib.pyplot as plt

conn = sqlite3.connect('marvel.db')
query = 'SELECT year, appearances FROM marvel WHERE year != \'\' ORDER BY year;'
query_res = conn.execute(query)

years = []
appearances = []
for row in query_res:
    years.append(int(row[0]))
    appearances.append(int(row[1]))

num_bins = 30

fig = plt.figure()
ax = fig.add_subplot(1, 1, 1)

n, bins, patches = ax.scatter(years, weights=appearances)
ax.set_xlabel('Appearances')
ax.set_ylabel('Year')
ax.set_title('Plot of marvel character appearances by year')
plt.show()