f = open('names.txt', 'r')
names = {}
for line in f:
    n = line.strip('\n')
    names[n] = ''

print('number of unique names: ' + str(len(names)))
