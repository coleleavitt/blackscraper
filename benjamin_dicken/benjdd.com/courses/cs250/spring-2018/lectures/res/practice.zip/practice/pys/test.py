data = ['NAME', 'IDENTITY', 'AGE', 'TIME']
other = data[1:3]
result = other[0]

print(result)