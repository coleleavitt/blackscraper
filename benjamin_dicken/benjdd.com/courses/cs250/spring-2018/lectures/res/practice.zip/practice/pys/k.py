def make_changes(items):
    items.append('nails')
    items.append('wood')
    items = 'begin'

name = 'James'
construct = ['drill', 'screws']
make_changes(construct)
name = 'John'

print(name)
print(construct)
