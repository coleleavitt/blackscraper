def tuple_sum(t):
    s = 0
    for i in t:
        s += i
    return s

def min_sum(tups):
    min_s = tuple_sum(tups[0])
    tup_s = tups[0]
    for i in range(0, len(tups)):
        current_sum = tuple_sum(tups[i])
        if current_sum <= min_s:
            min_s = current_sum
            tup_s = tups[i]
    return tup_s

print(min_sum( [(3,2), (4,1,5,6,7), (1,2,2), (30000, 100), (12345, -4)] ))
print(min_sum( [(0,0), (1,2), (2,1), (-1, -3)] ))

    