def main():
    file_name = input('Enter your grade file: ')
    f = open(file_name, 'r')
    lines = f.readlines()
    for line in lines:
        sp = line.split(' : ')
        name = sp[0]
        grade = float(sp[1])
        if grade > 90:
            print(name + ' got an A')
        elif grade > 80:
            print(name + ' got an B')
        elif grade > 70:
            print(name + ' got an C')
        elif grade > 60:
            print(name + ' got an D')
        else:
            print(name + ' got an F')
    
main()