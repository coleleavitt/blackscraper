def main():
    file_name = input('Enter your grade file: ')
    f = open(file_name, 'a')
    name = input('Enter your student\'s name: ')
    grade = input('Enter the associated grade: ')
    out = name + ' : ' + str(grade)
    f.write('\n' + out)
    f.flush()
    
main()