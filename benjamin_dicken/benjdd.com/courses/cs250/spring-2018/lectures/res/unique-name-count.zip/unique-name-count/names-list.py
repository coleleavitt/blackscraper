f = open('names.txt', 'r')
names = []
for line in f:
    n = line.strip('\n')
    if n not in names:
        names.append(n)

print('number of unique names: ' + str(len(names)))
