f = open('names.txt', 'r')
names = set()
for line in f:
    n = line.strip('\n')
    names.add(n)

print('number of unique names: ' + str(len(names)))
