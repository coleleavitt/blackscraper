marvel_titles = []
marvel_data = []
f = open('./marvel.csv', 'r')

first_line = f.readline()
titles = first_line.strip('\n').split(',')
marvel_titles = titles

for line in f:
    line = line.strip('\n')
    marvel_data.append(line)

print('The data titles are: ')
for t in titles:
    print(t, end='\t')
print()

for d in marvel_data:
    print(d)
