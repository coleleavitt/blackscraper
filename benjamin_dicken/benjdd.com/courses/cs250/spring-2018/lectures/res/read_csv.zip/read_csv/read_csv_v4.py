marvel_titles = []
marvel_data = []
f = open('./marvel.csv', 'r')

first_line = f.readline()
titles = first_line.strip('\n').split(',')
marvel_titles = titles

for line in f:
    line = line.strip('\n')
    line = line.split(',')
    marvel_data.append(line)

print('The data titles are: ')
for t in titles:
    print(t.ljust(12), end='')
print()

for row in marvel_data:
    for col in row:
        print(col.ljust(12), end='')
    print()
