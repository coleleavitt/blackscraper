marvel_data = []
f = open('./data.csv', 'r')

first_line = f.readline().strip('\n')
titles = first_line.split(',')

for line in f:
    line = line.strip('\n')
    line = line.split(',')
    marvel_data.append(line)
    
for t in titles:
    print(t.ljust(10), end='\t')
print()

for row in marvel_data:
    for col in row:
        print(col.ljust(10), end='\t')
    print()
    