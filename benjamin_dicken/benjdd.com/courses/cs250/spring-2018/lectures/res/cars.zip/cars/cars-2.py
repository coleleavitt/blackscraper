import sys
import matplotlib.pyplot as plt
import csv

data = list(csv.reader(open('cars.csv')))

hp = []
mpg = []
to = []
for i in data:
    to.append(float(i[14]))
    hp.append(float(i[7]))
    mpg.append(float(i[0]))

num_bins = 50

fig = plt.figure()
ax1 = fig.add_subplot(1, 3, 1)
ax1.scatter(hp, mpg, alpha=0.2, cmap=plt.cm.inferno)
ax2 = fig.add_subplot(1, 3, 2)
ax2.scatter(hp, to, alpha=0.2, cmap=plt.cm.inferno)
ax3 = fig.add_subplot(1, 3, 3)
ax3.scatter(to, mpg, alpha=0.2, cmap=plt.cm.inferno)
plt.show()