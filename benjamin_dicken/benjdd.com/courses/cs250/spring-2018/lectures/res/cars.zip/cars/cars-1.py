import sys
import matplotlib.pyplot as plt
import csv

data = list(csv.reader(open('cars.csv')))

year = []
mpg = []
for i in data:
    year.append(float(i[17]))
    mpg.append(float(i[0]))

num_bins = 50

fig = plt.figure()
ax = fig.add_subplot(1, 1, 1)

ax.scatter(year, mpg, cmap=plt.cm.inferno, alpha=0.2)
ax.set_xlabel('year')
ax.set_ylabel('mpg')
ax.set_title('Car data')
plt.show()