import sys

maze = [[1, 1, 1, 1, 1, 0, 1, 1],
        [1, 0, 1, 0, 0, 0, 0, 1],
        [1, 0, 1, 1, 1, 0, 1, 1],
        [1, 0, 1, 0, 1, 0, 0, 1],
        [1, 0, 1, 1, 1, 1, 0, 1],
        [1, 0, 0, 0, 0, 0, 0, 1],
        [1, 0, 1, 1, 1, 1, 1, 1],
        [1, 0, 0, 0, 0, 0, 5, 1],
        [1, 1, 1, 1, 1, 1, 1, 1]]
         
def has_won(i, j):
    return i == 0 or j == 0 or i == len(maze)-1 or j == len(maze[0])-1
    
def main():
    start_i = 0
    start_j = 0;
    for i in range(0, len(maze)):
        for j in range(0, len(maze[i])):
            if (maze[i][j] == 5):
                start_i = i
                start_j= j
    print(start_i)
    print(start_j)
    
    ci = start_i
    cj = start_j
    
    while not has_won(ci, cj):
        if maze[ci-1][cj] == 0:
            maze[ci][cj] = 2
            ci -= 1
            print('UP')
        elif maze[ci+1][cj] == 0:
            maze[ci][cj] = 2
            ci += 1
            print('DOWN')
        elif maze[ci][cj+1] == 0:
            maze[ci][cj] = 2
            cj += 1
            print('RIGHT')
        elif maze[ci][cj-1] == 0:
            maze[ci][cj] = 2
            cj -= 1
            print('LEFT')
        sys.stdout.flush()
        
    
    
    

main()