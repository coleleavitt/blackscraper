import csv

csv_file = open('data.csv')
reader = csv.reader(csv_file)
titles = []

i = 0
for row in reader:
    if i == 0:
        ### Titles
        for col in row:
            print(col.ljust(18), end='|')
    else:
        for col in row:
            print(col.ljust(18), end=' ')
    print()
    i += 1

### TODO
