import csv

csv_file = open('marvel-data.csv')
limit = input('How many to show? ')
column = input('column number? ')

reader = csv.reader(csv_file)
titles = []

column_list = []

i = 0
for row in reader:
    if i != 0:
        for j in range(len(row)):
            if j == int(column):
                column_list.append(int(row[j]))
    i += 1

column_list.sort()
column_list.reverse()

print(column_list[0:5])

csv_file = open('marvel-data.csv')
reader = csv.reader(csv_file)
i = 0
for row in reader:
    if i != 0:
        if int(row[int(column)]) in column_list[0:5]:
            print (row[0])
    i += 1
