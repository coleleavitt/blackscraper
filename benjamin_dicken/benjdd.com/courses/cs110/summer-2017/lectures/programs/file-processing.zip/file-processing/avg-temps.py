def main():
    file_name = input('Enter your temperature file: ')
    f = open(file_name, 'r')
    lines = f.readlines()
    for line in lines:
        sp = line.split(': ')
        day = sp[0]
        numbers_str = sp[1]
        n = numbers_str.split(', ')
        total = 0
        for num in n:
            total = total + float(num)
        avg = total / len(n)
        print('The average temp on ' + day + ' was ' + str(avg))
    
main()