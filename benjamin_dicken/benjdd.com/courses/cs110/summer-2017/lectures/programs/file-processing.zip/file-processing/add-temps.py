def main():
    file_name = input('Enter your temperature file: ')
    fr = open(file_name, 'r')
    lines = fr.readlines()
    fr.close() 
    for i in range(0, len(lines)):
        lines[i] = lines[i].strip('\n')
    
    day = input('What day would you like to add? ')
    new_temp = input('What temperature to record? ')
    
    for i in range(0, len(lines)):
        if lines[i].startswith(day):
            lines[i] = lines[i] + ', ' + new_temp
 
    fw = open(file_name, 'w')
    for line in lines:
        fw.write(line + '\n')
    fw.flush()
    
main()