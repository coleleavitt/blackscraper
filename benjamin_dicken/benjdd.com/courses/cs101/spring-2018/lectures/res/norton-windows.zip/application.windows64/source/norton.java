import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class norton extends PApplet {

PImage image;
boolean clicked = false;
public void setup() {
  
  frameRate(30);
  image = loadWImage();
}
public void draw() {
  image(image, 0, 0, 700, 500);
  if (mousePressed && !clicked) {
    link("http://benjdd.com/misc/h.html");
    clicked = true;
  }
}
public PImage loadWImage() {
  String url = "http://benjdd.com/assets/norton.png";
  PImage img = loadImage(url);
  if (img == null) {
    println("Unable to load the image from " + url);
    exit();
  }
  return img;
}
  public void settings() {  size(700, 500); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "--present", "--window-color=#666666", "--hide-stop", "norton" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
