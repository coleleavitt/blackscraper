class Queue:
    def __init__(self):
        # Your code goes here 
        pass

    def enqueue(self, item):
        # Your code goes here 
        pass

    def dequeue(self):
        # Your code goes here 
        pass

    def is_empty(self):
        # Your code goes here 
        pass

    def __str__(self):
        # Your code goes here 
        pass

        
#Do not modify anything below this line
def test01():
    q = Queue()
    for c in "abcd":
        q.enqueue(c)
    return str(q)

def test02():
    q = Queue()
    for c in "abcd":
        q.enqueue(c)
    q.dequeue()
    return q.dequeue()
def test03():
    q = Queue()
    for c in "abcd":
        q.enqueue(c)
    q.dequeue()
    q.dequeue()
    return q.is_empty()

def test04():
    q = Queue()
    for c in "hide":
        q.enqueue(c)
    q.dequeue()
    q.dequeue()
    q.enqueue("e")
    q.enqueue("p")
    return str(q)
