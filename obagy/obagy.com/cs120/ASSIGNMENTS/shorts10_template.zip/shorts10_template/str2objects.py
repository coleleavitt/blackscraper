def str2objects(spec):
    # Your code goes here 
    pass
