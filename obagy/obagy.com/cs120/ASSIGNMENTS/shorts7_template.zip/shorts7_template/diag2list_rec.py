def diag2list_rec(grid):
    # your code here