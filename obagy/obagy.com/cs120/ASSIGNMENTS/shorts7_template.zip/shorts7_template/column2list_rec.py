def column2list_rec(grid, n):
    # your code here