def list2string(arglist):
    # your code here