def palindrome_list(arglist):
    # your code here