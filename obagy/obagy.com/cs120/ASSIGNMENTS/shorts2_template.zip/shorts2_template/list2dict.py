def list2dict(list2d):
    # your code here
