def update_dict2(dict2, key1, key2, value):
    # your code here
