def shuffle_dict(somedict):
    # your code here
