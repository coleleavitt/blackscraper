def invert_dict(origdict):
    # Your code goes here
