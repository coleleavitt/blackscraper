def sum_csv_string(csv_string):
    # your code here
