"""Implement your class here"""
class Color:
    pass