def canonicalize_date(date_str):
    pass  # Your code goes here!
