"""Implement your class here"""
class Temp:
    pass