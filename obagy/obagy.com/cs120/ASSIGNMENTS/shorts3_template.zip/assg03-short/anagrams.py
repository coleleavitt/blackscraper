class Word:
    """Implement your class here"""
    pass