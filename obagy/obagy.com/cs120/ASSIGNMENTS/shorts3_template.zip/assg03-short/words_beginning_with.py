def words_beginning_with(wordlist, head):
    pass