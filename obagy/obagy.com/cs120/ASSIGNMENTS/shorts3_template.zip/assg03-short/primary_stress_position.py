def primary_stress_position(phoneme_list):
    pass

