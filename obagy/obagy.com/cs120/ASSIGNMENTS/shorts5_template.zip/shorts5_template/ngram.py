def ngram(arglist, startpos, length):
    # your code here