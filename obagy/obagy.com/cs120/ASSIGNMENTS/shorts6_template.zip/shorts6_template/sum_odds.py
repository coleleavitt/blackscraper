def sum_odds(alist):
    # Your code goes here
    pass