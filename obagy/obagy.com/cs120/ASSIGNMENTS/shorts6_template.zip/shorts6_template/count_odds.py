def count_odds(alist):
    #Your code goes here
    pass