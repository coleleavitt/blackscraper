def fmt(spec, values):
    # your code here