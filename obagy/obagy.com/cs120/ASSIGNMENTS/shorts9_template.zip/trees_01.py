class BinarySearchTree:
    def __init__(self):
        # your code here
    
    
    def add(self, value):
        # your code here
    
    
    def find(self, value):
        # your code here
        
    
    def __str__(self):
        # your code here
        