def shift_tuple(tup, value):
   #put your code here